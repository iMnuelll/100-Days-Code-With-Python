import streamlit as st
import seaborn as sns
import matplotlib.pyplot as plt
from bike_sharing_dataset import day_df

colors = ["#D3D3D3", "#D3D3D3", "#72BCD4"]

plt.figure(figsize=(10, 5))
sns.barplot(
    y=day_df['cnt'],
    x=day_df['season'],
    data=day_df.sort_values(by="cnt", ascending=False),
    hue="season",
    palette=colors
)
plt.title("Jumlah Pelanggan Berdasarkan Musim", loc="center")
plt.ylabel("Jumlah Pelanggan")
plt.xlabel("Musim")
plt.tick_params(axis="x", labelsize=12)
st.pyplot(plt)

colors = ["#D3D3D3", "#72BCD4"]
plt.figure(figsize=(10, 5))
sns.barplot(
    y = day_df['cnt'],
    x = day_df['workingday'],
    data=day_df.sort_values(by="cnt", ascending=False),
    hue = "workingday",
    palette=colors
)
plt.title("Numbers of Customer in Working Day",loc="center")
plt.ylabel("Customer Count")
plt.xlabel(None)
plt.tick_params(axis="x", labelsize=12)

st.pyplot(plt)
