# Proyek Akhir Belajar Analisis Data Dengan Python
Repository ini berisi proyek analisis data yang saya kerjakan setelah belajar dengan dicoding.

## Struktur Direktori
- /data : Direktori ini berisi data yang digunakan dalam proyek ini dengan format .csv.
- /dashboard : Direktori ini berisi file yang digunakan dalam pembuatan dashboard
- Latihan_analisis_data.ipynb : File ini berisi analisis data.