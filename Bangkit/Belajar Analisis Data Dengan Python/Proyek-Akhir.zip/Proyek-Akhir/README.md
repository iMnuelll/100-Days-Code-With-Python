# Proyek Akhir Belajar Analisis Data Dengan Python
Repository ini berisi proyek analisis data yang saya kerjakan setelah belajar dengan dicoding.

## Struktur Direktori
- /data : Direktori ini berisi data yang digunakan dalam proyek ini dengan format .csv.
- /dashboard : Direktori ini berisi file yang digunakan dalam pembuatan dashboard
- Latihan_analisis_data.ipynb : File ini berisi analisis data.

## Menjalankan dashboard secara local
- Buka powershell
- Masuk ke direktori dasboard
- Jalankan perintah "streamlit run main.py"
- Browser akan otomatis membuka dashboard yang sudah dibuat

## Screenshot Dashboard sederhana menggunakan streamlit

![Screenshot 2024-03-11 172235](https://github.com/iMnuelll/Study-Machine-Learning/assets/107970871/3d997a2b-b285-440c-a1df-a0b5af6ef0c8)